#!/data/data/com.termux/files/usr/bin/bash
cd /data/data/com.termux/files/home/cdc_portal
python3 -m http.server 8000 --bind 0.0.0.0
