def member_portal():
    print("--- CDC COIN: AMBASSADOR LOGIN ---")
    member_id = input("Enter Member ID: ")
    print(f"\nWelcome, Ambassador {member_id}!")
    print("-" * 30)
    print("YOUR SUCCESSION FORM:")
    print("1. Spouse Name: [ ]")
    print("2. Primary Child: [ ]")
    print("3. Grandchild: [ ]")
    print("-" * 30)
    print("[SYSTEM NOTICE]: Founder's Data is ENCRYPTED.")
    print("Your data will be stored in the Mother Tree.")

if __name__ == "__main__":
    member_portal()
